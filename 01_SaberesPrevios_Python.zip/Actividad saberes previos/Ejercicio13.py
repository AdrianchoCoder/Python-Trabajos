# 13. Dada las horas trabajadas de una persona y el valor por hora. Calcular su salario e imprimirlo

horas_trabajadas = float(input("Ingrese las horas trabajadas: "))
salario = horas_trabajadas * 6189
print(f"El salario total es: ${salario}")