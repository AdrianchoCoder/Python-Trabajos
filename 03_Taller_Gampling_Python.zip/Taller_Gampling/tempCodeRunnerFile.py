    Nombre: {self._nombre}
    Telefono: {self._telefono}
    Email: {self._email}
    Identificacion: {self._identificacion}
    Identificacion: {self._cargo}
    Identificacion: {self._salario}
    Fecha de Ingreso: {self._fecha_ingreso}
    Antiguedad del empleado: {antiguedad}
    ''')