# Clase Cuenta Bancaria
class Cuenta:
    # Variable de clase para generar números de cuenta automáticamente
    contador_cuenta = 100001
    
    def __init__(self, documento="", saldo=0.0, interes_anual=0.0):
        """Constructor principal"""
        self._numero_cuenta = self.__generar_numero_cuenta()
        self._documento = documento
        self._saldo = saldo
        self._interes_anual = interes_anual
    
    def constructor_por_defecto(self):
        """Constructor por defecto - no hace nada extra"""
        pass
    
    def __generar_numero_cuenta(self):
        """Método privado que genera número de cuenta correlativo"""
        numero = Cuenta.contador_cuenta
        Cuenta.contador_cuenta += 1
        return numero
    
    def actualizarSaldo(self):
        """Actualiza el saldo aplicando el interés diario"""
        if self._saldo > 0:
            interes_diario = self._interes_anual / 365 / 100  # Convertir a decimal y dividir por días
            interes_ganado = self._saldo * interes_diario
            self._saldo += interes_ganado
            return interes_ganado
        return 0
    
    def ingresar(self, cantidad):
        """Permite ingresar dinero a la cuenta"""
        if cantidad > 0:
            self._saldo += cantidad
            return True
        else:
            print("Error: La cantidad debe ser mayor a 0")
            return False
    
    def retirar(self, cantidad):
        """Permite retirar dinero de la cuenta si hay saldo suficiente"""
        if cantidad <= 0:
            print("Error: La cantidad debe ser mayor a 0")
            return False
        elif cantidad > self._saldo:
            print(f"Error: Saldo insuficiente. Saldo actual: ${self._saldo:.2f}")
            return False
        else:
            self._saldo -= cantidad
            return True
    
    def mostrar_datos(self):
        """Muestra todos los datos de la cuenta"""
        print(f"""
        ╔══════════════════════════════════════╗
        ║           DATOS DE LA CUENTA         ║
        ╠══════════════════════════════════════╣
        ║ Número de Cuenta: {self._numero_cuenta:<15} ║
        ║ Documento Cliente: {self._documento:<14} ║
        ║ Saldo Actual: ${self._saldo:<19.2f} ║
        ║ Interés Anual: {self._interes_anual:<18.2f}% ║
        ╚══════════════════════════════════════╝
        """)
    
    def obtener_info_completa(self):
        """Devuelve información completa en formato string"""
        return (f"Cuenta N° {self._numero_cuenta} | Cliente: {self._documento} | "
                f"Saldo: ${self._saldo:.2f} | Interés: {self._interes_anual}%")
    
    # Métodos GET para obtener información
    def get_numero_cuenta(self):
        return self._numero_cuenta
    
    def get_documento(self):
        return self._documento
    
    def get_saldo(self):
        return self._saldo
    
    def get_interes_anual(self):
        return self._interes_anual
    
    # Métodos SET para modificar información (excepto número de cuenta)
    def set_documento(self, documento):
        self._documento = documento
    
    def set_interes_anual(self, interes):
        if interes >= 0:
            self._interes_anual = interes
        else:
            print("Error: El interés no puede ser negativo")


# Vista/Interfaz del usuario - Programa principal
def mostrar_menu():
    """Muestra el menú principal"""
    print("\n" + "="*50)
    print("           SISTEMA BANCARIO")
    print("="*50)
    print("1. Crear nueva cuenta")
    print("2. Ver datos de cuenta")
    print("3. Ingresar dinero")
    print("4. Retirar dinero") 
    print("5. Actualizar saldo (aplicar interés)")
    print("6. Listar todas las cuentas")
    print("7. Salir")
    print("="*50)

def crear_cuenta():
    """Función para crear una nueva cuenta"""
    print("\n--- CREAR NUEVA CUENTA ---")
    documento = input("Documento del cliente: ")
    
    try:
        saldo_inicial = float(input("Saldo inicial (0 si no deposita): $"))
        interes_anual = float(input("Interés anual (%): "))
        
        if saldo_inicial < 0:
            print("Error: El saldo no puede ser negativo")
            return None
        
        cuenta = Cuenta(documento, saldo_inicial, interes_anual)
        print(f"\n✅ Cuenta creada exitosamente!")
        print(f"Número de cuenta asignado: {cuenta.get_numero_cuenta()}")
        return cuenta
        
    except ValueError:
        print("Error: Por favor ingresa números válidos")
        return None

def buscar_cuenta(cuentas):
    """Busca una cuenta por número"""
    try:
        numero = int(input("Ingresa el número de cuenta: "))
        for cuenta in cuentas:
            if cuenta.get_numero_cuenta() == numero:
                return cuenta
        print("❌ Cuenta no encontrada")
        return None
    except ValueError:
        print("Error: Ingresa un número válido")
        return None

def main():
    """Función principal del programa"""
    cuentas = []  # Lista para almacenar todas las cuentas
    
    print("¡Bienvenido al Sistema Bancario!")
    
    while True:
        mostrar_menu()
        
        try:
            opcion = int(input("Selecciona una opción (1-7): "))
            
            if opcion == 1:
                # Crear nueva cuenta
                nueva_cuenta = crear_cuenta()
                if nueva_cuenta:
                    cuentas.append(nueva_cuenta)
            
            elif opcion == 2:
                # Ver datos de cuenta
                if not cuentas:
                    print("❌ No hay cuentas registradas")
                else:
                    print("\n--- VER DATOS DE CUENTA ---")
                    cuenta = buscar_cuenta(cuentas)
                    if cuenta:
                        cuenta.mostrar_datos()
            
            elif opcion == 3:
                # Ingresar dinero
                if not cuentas:
                    print("❌ No hay cuentas registradas")
                else:
                    print("\n--- INGRESAR DINERO ---")
                    cuenta = buscar_cuenta(cuentas)
                    if cuenta:
                        try:
                            cantidad = float(input("Cantidad a ingresar: $"))
                            if cuenta.ingresar(cantidad):
                                print(f"✅ Ingreso exitoso!")
                                print(f"Nuevo saldo: ${cuenta.get_saldo():.2f}")
                        except ValueError:
                            print("Error: Ingresa una cantidad válida")
            
            elif opcion == 4:
                # Retirar dinero
                if not cuentas:
                    print("❌ No hay cuentas registradas")
                else:
                    print("\n--- RETIRAR DINERO ---")
                    cuenta = buscar_cuenta(cuentas)
                    if cuenta:
                        print(f"Saldo actual: ${cuenta.get_saldo():.2f}")
                        try:
                            cantidad = float(input("Cantidad a retirar: $"))
                            if cuenta.retirar(cantidad):
                                print(f"✅ Retiro exitoso!")
                                print(f"Nuevo saldo: ${cuenta.get_saldo():.2f}")
                        except ValueError:
                            print("Error: Ingresa una cantidad válida")
            
            elif opcion == 5:
                # Actualizar saldo (interés)
                if not cuentas:
                    print("❌ No hay cuentas registradas")
                else:
                    print("\n--- APLICAR INTERÉS DIARIO ---")
                    cuenta = buscar_cuenta(cuentas)
                    if cuenta:
                        saldo_anterior = cuenta.get_saldo()
                        interes_ganado = cuenta.actualizarSaldo()
                        
                        if interes_ganado > 0:
                            print(f"✅ Interés aplicado!")
                            print(f"Saldo anterior: ${saldo_anterior:.2f}")
                            print(f"Interés ganado: ${interes_ganado:.2f}")
                            print(f"Nuevo saldo: ${cuenta.get_saldo():.2f}")
                        else:
                            print("ℹ️ No se aplicó interés (saldo en cero)")
            
            elif opcion == 6:
                # Listar todas las cuentas
                if not cuentas:
                    print("❌ No hay cuentas registradas")
                else:
                    print("\n--- TODAS LAS CUENTAS ---")
                    for i, cuenta in enumerate(cuentas, 1):
                        print(f"{i}. {cuenta.obtener_info_completa()}")
            
            elif opcion == 7:
                # Salir
                print("\n¡Gracias por usar el Sistema Bancario!")
                print("¡Hasta luego! 👋")
                break
            
            else:
                print("❌ Opción no válida. Selecciona entre 1-7")
        
        except ValueError:
            print("❌ Error: Por favor ingresa un número válido")
        
        # Pausa para que el usuario pueda leer los mensajes
        input("\nPresiona Enter para continuar...")


# Ejecutar el programa
if __name__ == "__main__":
    main()