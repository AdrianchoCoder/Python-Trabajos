# EJERCICIO: CAFETERA - VERSIÓN SÚPER SENCILLA PARA APRENDER

# Clase Cafetera
class Cafetera:
    
    # Constructor por defecto (sin parámetros)
    def __init__(self, capacidad_maxima=1000, cantidad_actual=0):
        """
        Constructor de la cafetera
        - Por defecto: capacidad 1000cc, cantidad 0cc
        - Si le das valores, los usa pero verifica que sea correcto
        """
        self.capacidad_maxima = capacidad_maxima
        
        # Verificar que la cantidad actual no sea mayor que la capacidad
        if cantidad_actual > capacidad_maxima:
            self.cantidad_actual = capacidad_maxima
            print(f"⚠️ Ajustado: La cantidad era muy grande, se puso al máximo ({capacidad_maxima}cc)")
        else:
            self.cantidad_actual = cantidad_actual
    
    # Método para llenar completamente la cafetera
    def llenarCafetera(self):
        """Llena la cafetera al máximo"""
        self.cantidad_actual = self.capacidad_maxima
        print(f"☕ Cafetera llena! Ahora tiene {self.cantidad_actual}cc de café")
    
    # Método para servir una taza
    def servirTaza(self, cantidad_taza):
        """
        Sirve una taza con la cantidad pedida
        Si no hay suficiente café, sirve lo que quede
        """
        print(f"\n🍵 Sirviendo taza de {cantidad_taza}cc...")
        
        if self.cantidad_actual == 0:
            print("❌ La cafetera está vacía! No se puede servir nada")
            return 0
        
        # Si hay suficiente café
        if self.cantidad_actual >= cantidad_taza:
            self.cantidad_actual -= cantidad_taza
            print(f"✅ Taza servida con {cantidad_taza}cc")
            print(f"Café restante en la cafetera: {self.cantidad_actual}cc")
            return cantidad_taza
        
        # Si no hay suficiente, sirve lo que quede
        else:
            cafe_servido = self.cantidad_actual
            self.cantidad_actual = 0
            print(f"⚠️ Solo había {cafe_servido}cc. Se sirvió todo lo que quedaba")
            print("Cafetera ahora vacía")
            return cafe_servido
    
    # Método para vaciar la cafetera
    def vaciarCafetera(self):
        """Vacía completamente la cafetera"""
        self.cantidad_actual = 0
        print("🗑️ Cafetera vaciada completamente")
    
    # Método para agregar café
    def agregarCafe(self, cantidad):
        """
        Agrega café a la cafetera
        No puede superar la capacidad máxima
        """
        print(f"\n➕ Agregando {cantidad}cc de café...")
        
        if cantidad <= 0:
            print("❌ No puedes agregar cantidades negativas o cero")
            return
        
        # Verificar si cabe todo el café
        if self.cantidad_actual + cantidad <= self.capacidad_maxima:
            self.cantidad_actual += cantidad
            print(f"✅ Café agregado! Ahora hay {self.cantidad_actual}cc")
        else:
            # Solo agregar lo que cabe
            cafe_que_cabe = self.capacidad_maxima - self.cantidad_actual
            self.cantidad_actual = self.capacidad_maxima
            print(f"⚠️ Solo cabían {cafe_que_cabe}cc. Cafetera llena al máximo")
    
    # Método para mostrar el estado actual
    def mostrarEstado(self):
        """Muestra información actual de la cafetera"""
        print("\n" + "="*40)
        print("         ESTADO DE LA CAFETERA")
        print("="*40)
        print(f"Capacidad máxima: {self.capacidad_maxima}cc")
        print(f"Cantidad actual:  {self.cantidad_actual}cc")
        print(f"Espacio libre:    {self.capacidad_maxima - self.cantidad_actual}cc")
        
        # Mostrar porcentaje
        porcentaje = (self.cantidad_actual / self.capacidad_maxima) * 100
        print(f"Nivel de llenado: {porcentaje:.1f}%")
        
        # Mostrar gráfico sencillo
        barras_llenas = int(porcentaje / 10)
        barras_vacias = 10 - barras_llenas
        grafico = "█" * barras_llenas + "░" * barras_vacias
        print(f"Visual: [{grafico}]")
        print("="*40)


# PROGRAMA PRINCIPAL - MUY FÁCIL DE ENTENDER
def main():
    print("☕ BIENVENIDO AL SIMULADOR DE CAFETERA ☕")
    print("Vamos a crear y usar una cafetera virtual!")
    
    # Variable para guardar nuestra cafetera
    mi_cafetera = None
    
    while True:
        # Mostrar menú sencillo
        print("\n¿Qué quieres hacer?")
        print("1. Crear cafetera (por defecto)")
        print("2. Crear cafetera (personalizada)")
        print("3. Llenar cafetera")
        print("4. Servir una taza")
        print("5. Agregar café")
        print("6. Vaciar cafetera")
        print("7. Ver estado de la cafetera")
        print("8. Salir")
        
        # Pedir opción
        opcion = input("\nElige una opción (1-8): ")
        
        # Opción 1: Crear cafetera por defecto
        if opcion == "1":
            mi_cafetera = Cafetera()  # Usa valores por defecto
            print("✅ Cafetera creada con capacidad de 1000cc (vacía)")
        
        # Opción 2: Crear cafetera personalizada
        elif opcion == "2":
            try:
                print("\n📝 Crear cafetera personalizada:")
                capacidad = int(input("Capacidad máxima (cc): "))
                cantidad = int(input("Cantidad inicial (cc): "))
                
                mi_cafetera = Cafetera(capacidad, cantidad)
                print("✅ Cafetera personalizada creada!")
                
            except ValueError:
                print("❌ Error: Debes escribir números enteros")
        
        # Verificar si hay cafetera creada para las demás opciones
        elif mi_cafetera is None:
            print("❌ Primero debes crear una cafetera (opción 1 o 2)")
        
        # Opción 3: Llenar cafetera
        elif opcion == "3":
            mi_cafetera.llenarCafetera()
        
        # Opción 4: Servir taza
        elif opcion == "4":
            try:
                cantidad = int(input("¿Cuántos cc quieres en la taza? "))
                mi_cafetera.servirTaza(cantidad)
            except ValueError:
                print("❌ Error: Debes escribir un número entero")
        
        # Opción 5: Agregar café
        elif opcion == "5":
            try:
                cantidad = int(input("¿Cuántos cc de café vas a agregar? "))
                mi_cafetera.agregarCafe(cantidad)
            except ValueError:
                print("❌ Error: Debes escribir un número entero")
        
        # Opción 6: Vaciar cafetera
        elif opcion == "6":
            mi_cafetera.vaciarCafetera()
        
        # Opción 7: Ver estado
        elif opcion == "7":
            mi_cafetera.mostrarEstado()
        
        # Opción 8: Salir
        elif opcion == "8":
            print("\n☕ ¡Gracias por usar el simulador de cafetera!")
            print("¡Que disfrutes tu café! ☕")
            break
        
        # Opción incorrecta
        else:
            print("❌ Opción incorrecta. Elige del 1 al 8")
        
        # Pausa para leer
        input("\nPresiona Enter para continuar...")


# Función extra para hacer pruebas automáticas (opcional)
def pruebas_automaticas():
    """Función para probar la cafetera automáticamente"""
    print("🧪 EJECUTANDO PRUEBAS AUTOMÁTICAS...")
    
    # Crear cafetera
    cafetera = Cafetera(500, 200)  # Capacidad 500cc, cantidad inicial 200cc
    cafetera.mostrarEstado()
    
    # Servir algunas tazas
    cafetera.servirTaza(100)  # Debería servir 100cc
    cafetera.servirTaza(150)  # Debería servir solo 100cc (lo que queda)
    
    # Agregar café
    cafetera.agregarCafe(300)  # Debería agregar 300cc
    cafetera.agregarCafe(500)  # Debería llenar solo hasta el máximo
    
    # Mostrar estado final
    cafetera.mostrarEstado()


# Ejecutar el programa
if __name__ == "__main__":
    # Puedes elegir cuál ejecutar:
    main()  # Programa interactivo
    # pruebas_automaticas()  # Descomenta esta línea para ver las pruebas