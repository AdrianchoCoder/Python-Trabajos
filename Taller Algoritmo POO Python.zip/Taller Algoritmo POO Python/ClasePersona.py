# Clase Persona completa
class Persona:
    # Variable de clase para generar DNI automáticamente
    contador_dni = 1
    
    def __init__(self, documento="", nombre="", edad=0, sexo="M", peso=0.0, altura=0.0):
        """Constructor principal con todos los parámetros"""
        self._documento = documento
        self._nombre = nombre
        self._edad = edad
        self._sexo = sexo
        self._peso = peso
        self._altura = altura
        self._DNI = self.__generaDNI()  # Se genera automáticamente
        self.__comprobarSexo()  # Verifica que el sexo sea válido
    
    def constructor_por_defecto(self):
        """Constructor por defecto - no hace nada"""
        pass
    
    def constructor_basico(self, documento, nombre, edad, sexo):
        """Constructor con información básica"""
        self._documento = documento
        self._nombre = nombre
        self._edad = edad
        self._sexo = sexo
        self._peso = 0.0
        self._altura = 0.0
        self._DNI = self.__generaDNI()
        self.__comprobarSexo()
    
    # Métodos principales
    def calcularIMC(self):
        """Calcula el IMC y devuelve el código correspondiente"""
        if self._peso == 0 or self._altura == 0:
            return -2  # Error: datos faltantes
        
        imc = self._peso / ((self._altura/100) ** 2)
        
        if imc < 18.5:
            return -1  # Por debajo del peso
        elif imc <= 24.9:
            return 0   # Normal
        elif imc <= 29.9:
            return 1   # Sobrepeso
        elif imc <= 39.9:
            return 2   # Obesidad
        else:
            return 3   # Obesidad extrema
    
    def obtener_categoria_imc(self):
        """Devuelve el texto de la categoría del IMC"""
        codigo = self.calcularIMC()
        categorias = {
            -2: "Datos incompletos",
            -1: "Por debajo del peso",
            0: "Normal",
            1: "Sobrepeso",
            2: "Obesidad",
            3: "Obesidad extrema"
        }
        return categorias.get(codigo, "Error")
    
    def esMayorDeEdad(self):
        """Indica si es mayor de edad"""
        return self._edad >= 18
    
    def __comprobarSexo(self):
        """Método privado que verifica el sexo"""
        if self._sexo not in ["M", "F"]:
            self._sexo = "M"
    
    def __generaDNI(self):
        """Método privado que genera DNI auto-incrementable"""
        dni = Persona.contador_dni
        Persona.contador_dni += 1
        return dni
    
    def listarInformacion(self):
        """Devuelve la información completa del objeto"""
        genero = "Masculino" if self._sexo == "M" else "Femenino"
        return (f"Hola {self._nombre}, tu código dentro del sistema es {self._DNI}. "
                f"Tu identificación es {self._documento}. Tu edad es {self._edad} años. "
                f"Tu género es {genero}. Tu peso es {self._peso} kg y tu altura es {self._altura} cm. "
                f"Al calcular tu IMC concluimos que tu peso está: {self.obtener_categoria_imc()}.")
    
    # Métodos GET (obtener valores)
    def get_documento(self):
        return self._documento
    
    def get_nombre(self):
        return self._nombre
    
    def get_edad(self):
        return self._edad
    
    def get_sexo(self):
        return self._sexo
    
    def get_peso(self):
        return self._peso
    
    def get_altura(self):
        return self._altura
    
    # Métodos SET (cambiar valores)
    def set_documento(self, documento):
        self._documento = documento
    
    def set_nombre(self, nombre):
        self._nombre = nombre
    
    def set_edad(self, edad):
        self._edad = edad
    
    def set_sexo(self, sexo):
        self._sexo = sexo
        self.__comprobarSexo()  # Verifica que sea válido
    
    def set_peso(self, peso):
        self._peso = peso
    
    def set_altura(self, altura):
        self._altura = altura


# Clase ejecutable - Programa principal
def main():
    print("=== SISTEMA DE REGISTRO DE PERSONAS ===\n")
    
    while True:
        # Pedir datos por teclado
        print("Ingresa los datos de la persona:")
        documento = input("Documento: ")
        nombre = input("Nombre: ")
        edad = int(input("Edad: "))
        sexo = input("Sexo (M/F): ").upper()
        peso = float(input("Peso (kg): "))
        altura = float(input("Altura (cm): "))
        
        print("\n" + "="*50)
        print("CREANDO LOS 3 OBJETOS...")
        print("="*50)
        
        # Crear los 3 objetos
        # Objeto 1: Con todos los datos
        persona1 = Persona(documento, nombre, edad, sexo, peso, altura)
        
        # Objeto 2: Solo con datos básicos (sin peso y altura)
        persona2 = Persona()
        persona2.constructor_basico(documento, nombre, edad, sexo)
        
        # Objeto 3: Por defecto, usando métodos set
        persona3 = Persona()
        persona3.constructor_por_defecto()
        persona3.set_documento("12345678")
        persona3.set_nombre("Juan Pérez")
        persona3.set_edad(25)
        persona3.set_sexo("M")
        persona3.set_peso(70.0)
        persona3.set_altura(175.0)
        
        # Lista de personas para procesar
        personas = [persona1, persona2, persona3]
        nombres_objetos = ["PRIMER OBJETO", "SEGUNDO OBJETO", "TERCER OBJETO"]
        
        # Procesar cada objeto
        for i, persona in enumerate(personas):
            print(f"\n--- {nombres_objetos[i]} ---")
            
            # Comprobar IMC
            categoria_imc = persona.obtener_categoria_imc()
            print(f"Categoría IMC: {categoria_imc}")
            
            # Verificar si es mayor de edad
            if persona.esMayorDeEdad():
                print("Es mayor de edad: SÍ")
            else:
                print("Es mayor de edad: NO")
            
            # Mostrar información completa
            print("Información completa:")
            print(persona.listarInformacion())
        
        # Preguntar si quiere continuar
        print("\n" + "="*50)
        continuar = input("¿Deseas ingresar otra persona? (s/n): ").lower()
        if continuar != 's':
            break
        print()
    
    print("¡Gracias por usar el sistema!")


# Ejecutar el programa
if __name__ == "__main__":
    main()